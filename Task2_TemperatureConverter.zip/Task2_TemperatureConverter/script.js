function convertTemperature(){

    let temp =
    parseFloat(document.getElementById("temperature").value);

    let unit =
    document.getElementById("unit").value;

    let result = "";

    if(isNaN(temp)){
        document.getElementById("result").innerHTML =
        "Please enter a valid number";
        return;
    }

    if(unit === "celsius"){
        result = (temp * 9/5) + 32;
        document.getElementById("result").innerHTML =
        temp + " °C = " + result.toFixed(2) + " °F";
    }

    else if(unit === "fahrenheit"){
        result = (temp - 32) * 5/9;
        document.getElementById("result").innerHTML =
        temp + " °F = " + result.toFixed(2) + " °C";
    }

    else if(unit === "kelvin"){
        result = temp - 273.15;
        document.getElementById("result").innerHTML =
        temp + " K = " + result.toFixed(2) + " °C";
    }
}